package com.example.rahultheboss.rideover;

/**
 * Created by TwinkleMistry on 4/19/2016.
 */
public class Rides {
    String sr_name;
    String sr_leaving_from;
    String sr_going_to;

    public void setSr_name(String sr_name){

        this.sr_name = sr_name;
    }
    public String getSr_name(){

        return this.sr_name;
    }

    public void setSr_leaving_from(String sr_leaving_from){

        this.sr_leaving_from = sr_leaving_from;
    }
    public String getSr_leaving_from(){

        return this.sr_leaving_from;
    }

    public void setSr_going_to(String sr_going_to){

        this.sr_going_to = sr_going_to;
    }
    public String getSr_going_to(){

        return this.sr_going_to;
    }
}
