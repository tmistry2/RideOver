package com.example.rahultheboss.rideover;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.FragmentTransaction;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;
import java.util.Calendar;

public class ShareARide extends AppCompatActivity implements View.OnClickListener{
    EditText Name, StartPoint, Destination, StartDate;
    Context context;
    UserDbHelper userDbHelper;
    SQLiteDatabase sqLiteDatabase;
    Button btnDatePicker, btnTimePicker;
    EditText txtDate, txtTime;
    private int mYear, mMonth, mDay, mHour, mMinute;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_aride);
        Name = (EditText) findViewById(R.id.editText3);
        StartPoint = (EditText) findViewById(R.id.editText);
        Destination = (EditText) findViewById(R.id.editText2);
        StartDate = (EditText) findViewById(R.id.editText6);

        OnClickShareTheRide();

        btnDatePicker=(Button)findViewById(R.id.calender_button);
        btnTimePicker=(Button)findViewById(R.id.clock_button);

        txtDate=(EditText)findViewById(R.id.editText6);
        txtTime=(EditText)findViewById(R.id.editText8);

        btnDatePicker.setOnClickListener(this);
        btnTimePicker.setOnClickListener(this);
    }

    public void addRide(View view){
        String name = Name.getText().toString();
        String startdest = StartPoint.getText().toString();
        String dest = Destination.getText().toString();
        String startdate = StartDate.getText().toString();

        userDbHelper = new UserDbHelper(context);
        sqLiteDatabase = userDbHelper.getWritableDatabase();
        userDbHelper.addInfo(name, startdest, dest, startdate, sqLiteDatabase);

        Toast.makeText(getBaseContext(), "Ride Shared", Toast.LENGTH_LONG).show();
        userDbHelper.close();

    }

    public void OnClickShareTheRide(){
        Button share_button = (Button)findViewById(R.id.share_confirm);
        share_button.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent("com.example.rahultheboss.rideover.HomeScreen");
                        startActivity(i);
                    }
                }

        );
    }
    public void onClick(View v) {

        if (v == btnDatePicker) {

            // Get Current Date
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);


            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            txtDate.setText( (monthOfYear + 1) + "-" + dayOfMonth + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if (v == btnTimePicker) {

            // Get Current Time
            final Calendar c = Calendar.getInstance();
            mHour = c.get(Calendar.HOUR_OF_DAY);
            mMinute = c.get(Calendar.MINUTE);

            // Launch Time Picker Dialog
            TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                    new TimePickerDialog.OnTimeSetListener() {

                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay,
                                              int minute) {
                            if(hourOfDay < 12) {
                                txtTime.setText(hourOfDay + ":" + minute + " AM");
                            }
                            else{
                                txtTime.setText(hourOfDay-12 + ":" + minute + " PM");
                            }
                        }
                    }, mHour, mMinute, false);
            timePickerDialog.show();
        }
    }

}
