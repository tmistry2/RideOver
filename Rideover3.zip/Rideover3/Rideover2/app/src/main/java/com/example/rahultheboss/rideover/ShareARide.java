package com.example.rahultheboss.rideover;

import android.app.Activity;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.EditText;
import android.widget.Toast;

public class ShareARide extends AppCompatActivity {
    EditText Name, StartPoint, Destination, StartDate;
    Context context;
    UserDbHelper userDbHelper;
    SQLiteDatabase sqLiteDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_aride);
        Name = (EditText) findViewById(R.id.editText3);
        StartPoint = (EditText) findViewById(R.id.editText);
        Destination = (EditText) findViewById(R.id.editText2);
        StartDate = (EditText) findViewById(R.id.editText6);

     //   OnClickShareTheRide();
    }

    public void addRide(View view){
        String name = Name.getText().toString();
        String startdest = StartPoint.getText().toString();
        String dest = Destination.getText().toString();
        String startdate = StartDate.getText().toString();

        userDbHelper = new UserDbHelper(context);
        sqLiteDatabase = userDbHelper.getWritableDatabase();
        userDbHelper.addInfo(name, startdest, dest, startdate, sqLiteDatabase);

        Toast.makeText(getBaseContext(), "Ride Shared", Toast.LENGTH_LONG).show();
        userDbHelper.close();

    }

  /*  public void OnClickShareTheRide(){
        Button share_button = (Button)findViewById(R.id.share_confirm);
        share_button.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent("com.example.rahultheboss.rideover.HomeScreen");
                        startActivity(i);
                    }
                }

        );
    }
    */
}
