package com.example.rahultheboss.rideover;

/**
 * Created by Kambi on 4/11/2016.
 */
public class RideInfo {

    public static abstract class NewRideInfo{
        public static final String USER_NAME = "user_name";
        public static final String USER_STARTPT = "starting_point";     //starting point
        public static final String USER_DEST = "destination";       //destination
        public static final String USER_DEPDATE = "depart_date";    //departure date
        public static final String TABLE_NAME = "ShareARide";


    }
}
