package com.example.rahultheboss.rideover;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.content.Intent;
import android.view.View;

public class GetARide extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_aride);
        OnClickGetARide();
    }

    public void OnClickGetARide() {
        Button get_ride_button = (Button) findViewById(R.id.get_a_ride_confirm);
        get_ride_button.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent("com.example.rahultheboss.rideover.HomeScreen");
                        startActivity(i);
                    }
                }

        );
    }
}
