package com.example.rahultheboss.rideover;

import android.app.DatePickerDialog;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Calendar;

public class GetARide extends AppCompatActivity implements View.OnClickListener {
    DatabaseHelper myDb = new DatabaseHelper(this);
    Button btnDatePicker;
    EditText txtDate;
    private int mYear, mMonth, mDay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_aride);
        OnClickGetARide();

        btnDatePicker=(Button)findViewById(R.id.calender_button);
        txtDate=(EditText)findViewById(R.id.gr_date_text_field);
        btnDatePicker.setOnClickListener(this);

    }

    public void OnClickGetARide() {
        Button get_ride_button = (Button) findViewById(R.id.get_a_ride_confirm);
        get_ride_button.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //Intent i = new Intent("com.example.rahultheboss.rideover.HomeScreen");
                        //startActivity(i);

                        EditText gr_leaving_from = (EditText)findViewById(R.id.gr_leaving_from_text_field);
                        String gr_leaving_from_string = gr_leaving_from.getText().toString();

                        EditText gr_going_to = (EditText)findViewById(R.id.gr_going_to_text_field);
                        String gr_going_to_string = gr_going_to.getText().toString();

                        String gr_date = txtDate.getText().toString();

                        if(gr_leaving_from_string.equals(""))
                        {
                            Toast.makeText(getApplicationContext(), "Leaving From Field is Empty!", Toast.LENGTH_LONG).show();
                            return;
                        }

                        if(gr_going_to_string.equals(""))
                        {
                            Toast.makeText(getApplicationContext(), "Going To Field is Empty!", Toast.LENGTH_LONG).show();
                            return;
                        }

                        if(gr_date.equals(""))
                        {
                            Toast.makeText(getApplicationContext(), "Date Field is Empty!", Toast.LENGTH_LONG).show();
                            return;
                        }

                        Cursor res = myDb.getAllData(gr_leaving_from_string, gr_going_to_string, gr_date);
                        if(res.getCount() == 0) {

                            //show message
                            showMessage("Sorry", "No rides found");
                            return;
                        }

                        StringBuffer buffer = new StringBuffer();
                        while(res.moveToNext()) {
                            buffer.append(res.getString(0));
                            buffer.append(" " + res.getString(1) + "\n");
                            buffer.append("Leaving from :" + res.getString(2) + "\n");
                            buffer.append("Going to :" + res.getString(3) + "\n");
                            buffer.append("Date :" + res.getString(4) + "\n");
                            buffer.append("Time :" + res.getString(5) + "\n");
                            buffer.append("Seats :" + res.getString(6) + "\n");
                            buffer.append("Price :" + res.getString(7) + "\n\n");

                        }

                        //Show data
                        showMessage("Rides", buffer.toString());
                    }
                }

        );
    }

    public void showMessage(String title, String Message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }

    @Override
    public void onClick(View v) {
        if (v == btnDatePicker) {

            // Get Current Date
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);


            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            txtDate.setText( (monthOfYear + 1) + "-" + dayOfMonth + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
    }
}
