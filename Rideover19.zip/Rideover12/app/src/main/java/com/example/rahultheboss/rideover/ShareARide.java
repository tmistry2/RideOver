package com.example.rahultheboss.rideover;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;

import java.util.Calendar;

public class ShareARide extends AppCompatActivity implements View.OnClickListener{
    Context context;
    DatabaseHelper helper = new DatabaseHelper(this);
    Button btnDatePicker, btnTimePicker;

    EditText txtDate, txtTime;
    private int mYear, mMonth, mDay, mHour, mMinute;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_aride);

        OnClickShareTheRide();

        //buttons on side of date and time
        btnDatePicker=(Button)findViewById(R.id.calender_button);
        btnTimePicker=(Button)findViewById(R.id.clock_button);

        //convert to text
        txtDate=(EditText)findViewById(R.id.sr_date_text_field);
        txtTime=(EditText)findViewById(R.id.sr_time_text_field);

        btnDatePicker.setOnClickListener(this);
        btnTimePicker.setOnClickListener(this);
    }


    public void onClick(View v) {

        if (v == btnDatePicker) {

            // Get Current Date
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);


            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {
                            txtDate.setText((monthOfYear + 1) + "-" + dayOfMonth + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if (v == btnTimePicker) {

            // Get Current Time
            final Calendar c = Calendar.getInstance();
            mHour = c.get(Calendar.HOUR_OF_DAY);
            mMinute = c.get(Calendar.MINUTE);

            // Launch Time Picker Dialog
            TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                    new TimePickerDialog.OnTimeSetListener() {

                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay,
                                              int minute) {

                            if(hourOfDay < 12) {

                                txtTime.setText(hourOfDay + ":" + minute + " AM");
                            }
                            else{
                                txtTime.setText(hourOfDay-12 + ":" + minute + " PM");
                            }
                        }
                    }, mHour, mMinute, false);
            timePickerDialog.show();
        }
    }
    public void OnClickShareTheRide(){
        Button share_button = (Button)findViewById(R.id.share_confirm);
        share_button.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        EditText sr_name = (EditText)findViewById(R.id.sr_name_text_field);
                        String sr_name_string = sr_name.getText().toString();

                        EditText sr_leaving_from = (EditText)findViewById(R.id.sr_leaving_from_text_field);
                        String sr_leaving_from_string = sr_leaving_from.getText().toString();

                        EditText sr_going_to = (EditText)findViewById(R.id.sr_going_to_text_field);
                        String sr_going_to_string = sr_going_to.getText().toString();

                        EditText sr_seats = (EditText)findViewById(R.id.sr_seats_text_field);
                        String sr_seats_string = sr_seats.getText().toString();
                        int sr_seats_int = Integer.parseInt(sr_seats_string);

                        EditText sr_price = (EditText)findViewById(R.id.sr_price_text_field);
                        String sr_price_string = sr_price.getText().toString();
                        int sr_price_int = Integer.parseInt(sr_price_string);

                        String sr_date = txtDate.getText().toString();
                        String sr_time = txtTime.getText().toString();



                        Intent i = new Intent("com.example.rahultheboss.rideover.HomeScreen");
                        startActivity(i);

                        Rides r = new Rides();
                        r.setSr_name(sr_name_string);
                        r.setSr_leaving_from(sr_leaving_from_string);
                        r.setSr_going_to(sr_going_to_string);
                        r.setSr_date(sr_date);
                        r.setSr_time(sr_time);
                        r.setSr_seats(sr_seats_int);
                        r.setSr_price(sr_price_int);



                        helper.insertRides(r);



                    }
                }

        );
    }


}
