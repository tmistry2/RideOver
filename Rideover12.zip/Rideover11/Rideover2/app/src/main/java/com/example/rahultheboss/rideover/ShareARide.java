package com.example.rahultheboss.rideover;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class ShareARide extends AppCompatActivity implements View.OnClickListener{
    Context context;
    DatabaseHelper helper = new DatabaseHelper(this);
    EditText name, leaving_from, going_to, seats, price;
    Button btnDatePicker, btnTimePicker;

    EditText txtDate, txtTime;
    private int mYear, mMonth, mDay, mHour, mMinute;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_aride);

        OnClickShareTheRide();

        //buttons on side of date and time
        btnDatePicker=(Button)findViewById(R.id.calender_button);
        btnTimePicker=(Button)findViewById(R.id.clock_button);

        //covnert to text
        txtDate=(EditText)findViewById(R.id.sr_date_text_field);
        txtTime=(EditText)findViewById(R.id.sr_time_text_field);
        name = (EditText)findViewById(R.id.sr_name_text_field);
        leaving_from = (EditText)findViewById(R.id.sr_leaving_from_text_field);
        going_to = (EditText)findViewById(R.id.sr_going_to_text_field);
        seats = (EditText)findViewById(R.id.sr_seats_text_field);
        price = (EditText)findViewById(R.id.sr_price_text_field);

        btnDatePicker.setOnClickListener(this);
        btnTimePicker.setOnClickListener(this);
    }


    public void onClick(View v) {

        if (v == btnDatePicker) {

            // Get Current Date
            final Calendar c = Calendar.getInstance();
            mYear = c.get(Calendar.YEAR);
            mMonth = c.get(Calendar.MONTH);
            mDay = c.get(Calendar.DAY_OF_MONTH);


            DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                    new DatePickerDialog.OnDateSetListener() {

                        @Override
                        public void onDateSet(DatePicker view, int year,
                                              int monthOfYear, int dayOfMonth) {

                            txtDate.setText( (monthOfYear + 1) + "-" + dayOfMonth + "-" + year);

                        }
                    }, mYear, mMonth, mDay);
            datePickerDialog.show();
        }
        if (v == btnTimePicker) {

            // Get Current Time
            final Calendar c = Calendar.getInstance();
            mHour = c.get(Calendar.HOUR_OF_DAY);
            mMinute = c.get(Calendar.MINUTE);

            // Launch Time Picker Dialog
            TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                    new TimePickerDialog.OnTimeSetListener() {

                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay,
                                              int minute) {
                            if(hourOfDay < 12) {
                                txtTime.setText(hourOfDay + ":" + minute + " AM");
                            }
                            else{
                                txtTime.setText(hourOfDay-12 + ":" + minute + " PM");
                            }
                        }
                    }, mHour, mMinute, false);
            timePickerDialog.show();
        }
    }
    public void OnClickShareTheRide(){
        Button share_button = (Button)findViewById(R.id.share_confirm);
        share_button.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String name_string = name.getText().toString();
                        String leaving_from_string = leaving_from.getText().toString();
                        String going_to_string = going_to.getText().toString();
                        String date_string = txtDate.getText().toString();
                        String time_string = txtTime.getText().toString();
                        String seats_string = seats.getText().toString();
                        String price_string = price.getText().toString();

                        Intent i = new Intent("com.example.rahultheboss.rideover.HomeScreen");
                        startActivity(i);

                        Share s = new Share();
                        s.setName(name_string);
                        s.setLeavingFrom(leaving_from_string);
                        s.setGoingTo(going_to_string);
                        s.setDate(date_string);
                        s.setTime(time_string);
                        s.setSeats(seats_string);
                        s.setPrice(price_string);

                        helper.insertRide(s);

                        if(helper.insertRide(s) == true){
                            Toast x = Toast.makeText(ShareARide.this, "Ride Shared!", Toast.LENGTH_SHORT);
                            x.show();
                        }

                    }
                }

        );
    }


}
