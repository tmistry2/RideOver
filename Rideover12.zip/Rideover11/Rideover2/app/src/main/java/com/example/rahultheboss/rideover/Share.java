package com.example.rahultheboss.rideover;

/**
 * Created by ttwin on 4/18/2016.
 */
public class Share {
    String name;
    String leaving_from;
    String going_to;
    String date;
    String time;
    String seats;
    String price;

    //name
    public void setName(String name){
        this.name = name;
    }
    public String getName(){
        return this.name;
    }

    //leaving_from
    public void setLeavingFrom(String username){
        this.leaving_from = leaving_from;
    }
    public String getLeavingFrom(){
        return this.leaving_from;
    }

    //going_to
    public void setGoingTo(String email){
        this.going_to = going_to;
    }
    public String getGoingTo(){
        return this.going_to;
    }

    //date
    public void setDate(String password){

        this.date = date;
    }
    public String getDate(){

        return this.date;
    }

    //time
    public void setTime(String password){

        this.time = time;
    }
    public String getTime(){

        return this.time;
    }

    //seats
    public void setSeats(String password){

        this.seats = seats;
    }
    public String getSeats(){

        return this.seats;
    }

    //price
    public void setPrice(String password){

        this.price = password;
    }
    public String getPrice(){

        return this.price;
    }

}
