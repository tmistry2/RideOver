package com.example.rahultheboss.rideover;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by ttwin on 4/16/2016.
 */
class DatabaseHelper extends SQLiteOpenHelper {


    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "Rideover.db";
    //table for sign up activity
    private static final String TABLE_CONTACTS = "contacts";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_PASSWORD = "password";


    // table for share activity


    private static final String TABLE_RIDES = "rides";
    private static final String COLUMN_RIDES_ID = "rides_id";
    private static final String COLUMN_RIDES_NAME = "rides_name";
    private static final String COLUMN_RIDES_LEAVING_FROM = "rides_leaving_from";
    private static final String COLUMN_RIDES_GOING_TO = "rides_going_to";
    private static final String COLUMN_RIDES_DATE = "rides_date";
    private static final String COLUMN_RIDES_TIME = "rides_time";
    private static final String COLUMN_RIDES_SEATS = "rides_seats";
    private static final String COLUMN_RIDES_PRICE = "rides_price";
    SQLiteDatabase db;


    private static final String TABLE_CONTACTS_2 = "create table contacts (id integer primary key not null , "
            + "name text not null, username text not null, email text not null, password text not null)";

    private static final String TABLE_RIDES_2 = "create table rides (id integer primary key not null , "
            + "rides_name text not null, rides_leaving_from text not null, " +
            "rides_going_to text not null, rides_date text not null, rides_time text not null, " +
            "rides_seats text not null, rides_price text not null)";


    public DatabaseHelper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    public void onCreate(SQLiteDatabase db){
        db.execSQL(TABLE_CONTACTS_2);
        db.execSQL(TABLE_RIDES_2);
        this.db = db;
    }
    public boolean insertContact(Contact c){
        db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        String query = "select * from contacts";
        Cursor cursor = db.rawQuery(query, null);

        int count = cursor.getCount();
        values.put(COLUMN_ID, count);
        values.put(COLUMN_NAME, c.getName());
        values.put(COLUMN_USERNAME, c.getUsernname());
        values.put(COLUMN_EMAIL, c.getEmail());
        values.put(COLUMN_PASSWORD, c.getPassword());

        db.insert(TABLE_CONTACTS, null, values);
        db.close();
        return true;

    }

    public boolean insertRide(Share s){
        db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        String query = "select * from rides";
        Cursor cursor = db.rawQuery(query, null);

        int count = cursor.getCount();
        values.put(COLUMN_RIDES_ID, count);
        values.put(COLUMN_RIDES_NAME, s.getName());
        values.put(COLUMN_RIDES_LEAVING_FROM, s.getLeavingFrom());
        values.put(COLUMN_RIDES_GOING_TO, s.getGoingTo());
        values.put(COLUMN_RIDES_DATE, s.getDate());
        values.put(COLUMN_RIDES_TIME, s.getTime());
        values.put(COLUMN_RIDES_SEATS, s.getSeats());
        values.put(COLUMN_RIDES_PRICE, s.getPrice());

        db.insert(TABLE_RIDES, null, values);
        db.close();
        return true;

    }
    public String search_password_string(String username){
        db = this.getReadableDatabase();
        String query = "select username, password from " + TABLE_CONTACTS;
        Cursor cursor = db.rawQuery(query, null);
        String a,b;
        b = "not found";
        if(cursor.moveToFirst()){
            do{
                a = cursor.getString(0);


                if(a.equals(username)){
                    b = cursor.getString(1);
                    break;
                }
            }
            while(cursor.moveToNext());

        }
        return b;
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String query = "DROP TABLE IF EXISTS" + TABLE_CONTACTS;
        String query_2 = "DROP TABLE IF EXISTS" + TABLE_RIDES;

        db.execSQL(query);
        this.onCreate(db);
    }


}
