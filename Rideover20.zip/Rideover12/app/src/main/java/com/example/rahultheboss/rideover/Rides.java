package com.example.rahultheboss.rideover;

/**
 * Created by TwinkleMistry on 4/19/2016.
 */
public class Rides {
    String sr_name;
    String sr_leaving_from;
    String sr_going_to;
    String sr_date;
    String sr_time;
    String sr_seats;
    String sr_price;

    public void setSr_name(String sr_name){

        this.sr_name = sr_name;
    }
    public String getSr_name(){

        return this.sr_name;
    }

    public void setSr_leaving_from(String sr_leaving_from){

        this.sr_leaving_from = sr_leaving_from;
    }
    public String getSr_leaving_from(){

        return this.sr_leaving_from;
    }

    public void setSr_going_to(String sr_going_to){

        this.sr_going_to = sr_going_to;
    }
    public String getSr_going_to(){

        return this.sr_going_to;
    }

    public void setSr_seats(String sr_seats){

        this.sr_seats = sr_seats;
    }
    public String getSr_seats(){

        return this.sr_seats;
    }

    public void setSr_price(String sr_price){

        this.sr_price = sr_price;
    }
    public String getSr_price(){

        return this.sr_price;
    }

    public void setSr_date(String sr_date){

        this.sr_date = sr_date;
    }
    public String getSr_date(){

        return this.sr_date;
    }

    public void setSr_time(String sr_time){

        this.sr_time = sr_time;
    }
    public String getSr_time(){

        return this.sr_time;
    }
}
