package com.example.rahultheboss.rideover;

import android.view.View;

/**
 * Created by SCanchiRadhakrishna on 4/26/16.
 */
public interface MyInterface {
    public void buttonClicked(View v);
}
