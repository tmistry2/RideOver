package com.example.rahultheboss.rideover;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.widget.Toast;

public class SignUpActivity extends Activity {
    DatabaseHelper helper = new DatabaseHelper(this);
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        OnRegisterClick();

    }

    //@Override
    public void OnRegisterClick(){
        Button register = (Button)findViewById(R.id.register_button);


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                EditText name = (EditText)findViewById(R.id.name_text_field);
                EditText username = (EditText)findViewById(R.id.username_text_field);
                EditText email = (EditText)findViewById(R.id.email_text_field);
                EditText password = (EditText)findViewById(R.id.password_text_field);


                String name_string = name.getText().toString();
                String username_string = username.getText().toString();
                String email_string = email.getText().toString();
                String password_string = password.getText().toString();


                Intent login = new Intent("com.example.rahultheboss.rideover.LoginActivity");
                startActivity(login);

                Contact c = new Contact();
                c.setName(name_string);
                c.setUsername(username_string);
                c.setEmail(email_string);
                c.setPassword(password_string);

                helper.insertContact(c);

            }
        });
    }


}
