package com.example.rahultheboss.rideover;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;

public class SignUpActivity extends AppCompatActivity {

    //Button register = (Button)findViewById(R.id.register_button);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        OnRegisterClick();

    }

    //@Override
    public void OnRegisterClick(){
        Button register = (Button)findViewById(R.id.register_button);
        EditText first_name = (EditText)findViewById(R.id.first_name_field);
        EditText last_name = (EditText)findViewById(R.id.last_name_field);
        EditText email = (EditText)findViewById(R.id.email_field);
        EditText password = (EditText)findViewById(R.id.password_field);

        String firstName = first_name.toString();
        String lastName = last_name.toString();
        String Email = email.toString();
        String Password = password.toString();
        //Push these four strings into the database

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent login = new Intent("com.example.rahultheboss.rideover.LoginActivity");
                startActivity(login);
            }
        });
    }


}
